export { default } from './DetailPage';
