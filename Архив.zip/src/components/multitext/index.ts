export { default } from './Multitext';
