export { default } from './SingleText';
